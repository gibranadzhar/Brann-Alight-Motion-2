# Railway deployment

1. Push this folder to GitHub.
2. In Railway, create a project and deploy the GitHub repository.
3. Railway should detect Node.js automatically.
4. Start command: `npm start` (already configured in package.json).
5. Add these Railway Variables:
   - `ADMIN_PASSWORD` = password for the admin/token setup
   - `SESSION_SECRET` = long random secret for Express sessions
6. Deploy, then use Railway Networking → Generate Domain.

The app listens on `process.env.PORT`, which Railway supplies automatically.
